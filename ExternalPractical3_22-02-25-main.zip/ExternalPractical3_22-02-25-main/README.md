# FITCLUB-GYM-Website
Creating Responsive &amp; Icream Parlour: Ice Cream Parlour Website  design using HTML &amp; CSS.

Clone the repository

create the website 

upload the it to your github repository

submit it to the google form.



